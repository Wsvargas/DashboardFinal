import os
import numpy as np
import pandas as pd
import streamlit as st
from datetime import datetime

# ── Módulos propios ───────────────────────────────────────────
from config import (
    MAIN_FILE, BENCH_FILE, RED, BLACK, BG, CARD, BORDER, TEXT, MUTED, GREEN, AMBER, BLUE,
)
from helpers import md, _file_mtime
from styles import inject_css
from data_loader import (
    load_and_prepare, load_ideales, build_snapshot_activos,
    enriquecer_historial_con_ideal,
)

# ── Módulos del dashboard ─────────────────────────────────────
from dashboard_kpis import render_kpis_globales
from dashboard_sec01 import render_sec01
from dashboard_sec02 import render_sec02
from dashboard_sec03 import render_sec03
from dashboard_sec04 import render_sec04

# ──────────────────────────────────────────────────────────────
# PAGE CONFIG
# ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="\n PRONACA | Producción Avícola v15",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ──────────────────────────────────────────────────────────────
# ROUTER simple (dashboard / predictiva)
# ──────────────────────────────────────────────────────────────
if "page" not in st.session_state:
    st.session_state["page"] = "dashboard"

def go_predictiva():
    st.session_state["page"] = "predictiva"
    st.rerun()

def go_dashboard():
    st.session_state["page"] = "dashboard"
    st.rerun()

if st.session_state["page"] == "predictiva":
    import tool_predictiva
    tool_predictiva.render(go_dashboard=go_dashboard)
    st.stop()

# ──────────────────────────────────────────────────────────────
# CSS
# ──────────────────────────────────────────────────────────────
inject_css()

# ──────────────────────────────────────────────────────────────
# PREDICTOR (cacheado por mtime del modelo)
# ──────────────────────────────────────────────────────────────
@st.cache_resource(show_spinner=False)
def get_predictor_cached(model_path: str, model_mtime: float):
    from model_predictor import cargar_predictor
    return cargar_predictor(model_path)

# ──────────────────────────────────────────────────────────────
# CARGA DE DATOS
# ──────────────────────────────────────────────────────────────
if not os.path.exists(MAIN_FILE):
    st.error(f"❌ No se encontró {MAIN_FILE}")
    st.stop()

with st.spinner("Cargando datos…"):
    DF_ALL = load_and_prepare(MAIN_FILE)
    IDEALES = load_ideales(BENCH_FILE)

with st.spinner("Procesando histórico comparable…"):
    DF_HIST_COMP = enriquecer_historial_con_ideal(DF_ALL, IDEALES)

with st.spinner("Procesando snapshot…"):
    SNAP = build_snapshot_activos(DF_HIST_COMP)

if SNAP.empty:
    st.warning("No hay lotes ACTIVO en el archivo.")
    st.stop()

# ── Session state ─────────────────────────────────────────────
if "lote_anterior" not in st.session_state:
    st.session_state.lote_anterior = None
if "prediccion_resultado" not in st.session_state:
    st.session_state.prediccion_resultado = None
if "lote_sel_sec03" not in st.session_state:
    st.session_state.lote_sel_sec03 = None
if "pred_cache" not in st.session_state:
    st.session_state["pred_cache"] = {}

# ──────────────────────────────────────────────────────────────
# HEADER
# ──────────────────────────────────────────────────────────────
hoy = datetime.today()
md(f"""
<div class="pronaca-header">
  <div>
    <div class="pronaca-header-title">----</div>
    <div class="pronaca-header-title">PRONACA · PRODUCCIÓN AVÍCOLA v15</div>
    <div class="pronaca-header-sub">Dashboard Interactivo · Con Botón de Predicción Manual</div>
  </div>
  <div class="pronaca-header-pill">📅 Corte {hoy:%d %b %Y}</div>
</div>
""")

# ──────────────────────────────────────────────────────────────
# FILTROS SUPERIORES
# ──────────────────────────────────────────────────────────────
md('<div class="filter-bar">')
fc1, fc2, fc3, fc4, fc5 = st.columns([1.3, 1.2, 1.2, 1.2, 1.35])
with fc1:
    sel_zona = st.multiselect("📍 Zona", ["BUCAY", "SANTO DOMINGO"], default=["BUCAY", "SANTO DOMINGO"])
with fc2:
    sel_tipo = st.multiselect("🏠 Tipo", ["PROPIA", "PAC"], default=["PROPIA", "PAC"])
with fc3:
    sel_quint = st.multiselect("🧩 Quintil", ["Q1", "Q2", "Q3", "Q4", "Q5"], default=["Q1", "Q2", "Q3", "Q4", "Q5"])
with fc4:
    sel_estado = st.multiselect("🔄 Estado", ["ABIERTO", "CERRADO"], default=["ABIERTO"])

# ── Snapshot filtrado por filtros globales ───────────────────
SF = SNAP.copy()
SF = SF[SF["ZonaNombre"].isin(sel_zona)]
SF = SF[SF["TipoStd"].isin(sel_tipo)]
SF = SF[SF["Quintil"].isin(sel_quint)]
SF = SF[SF["EstadoLote"].isin(sel_estado)]

if SF.empty:
    st.info("Sin datos para los filtros seleccionados.")
    st.stop()

LOTES_FILTRADOS = SF["LoteCompleto"].dropna().unique().tolist()
DF_FILTRADO = DF_HIST_COMP[DF_HIST_COMP["LoteCompleto"].isin(LOTES_FILTRADOS)].copy()

# ──────────────────────────────────────────────────────────────
# KPIs GLOBALES
# ──────────────────────────────────────────────────────────────
render_kpis_globales(SF)

# ──────────────────────────────────────────────────────────────
# LAYOUT PRINCIPAL
# ──────────────────────────────────────────────────────────────
left, right = st.columns([1, 1], gap="large")

# ══════════════════════════════════════════════════════════════
# COLUMNA IZQUIERDA
# ══════════════════════════════════════════════════════════════
with left:
    # Retorna etapas seleccionadas
    etapas_sel = render_sec01(SF, DF_HIST_COMP)
    
    # SF_02 con filtro de etapas
    SF_02 = SF.copy()
    if etapas_sel:
        SF_02 = SF_02[SF_02["Etapa"].isin(etapas_sel)]
    
    # Retorna lote seleccionado en sec02
    lote_sel = render_sec02(SF_02, DF_HIST_COMP, IDEALES)
    
    # Si hay lote seleccionado, renderizar sec03
    if lote_sel:
        st.session_state["lote_sel_sec03"] = lote_sel
    
    render_sec03(
        lote_sel=st.session_state.get("lote_sel_sec03"),
        SF=SF,
        DF_FILTRADO=DF_FILTRADO,
        DF_ALL=DF_ALL,
        IDEALES=IDEALES,
    )

# ══════════════════════════════════════════════════════════════
# COLUMNA DERECHA — SEC 04 · PREDICCIÓN
# ══════════════════════════════════════════════════════════════
with right:
    render_sec04(
        lote_sel=st.session_state.get("lote_sel_sec03"),
        SF=SF,
        DF_FILTRADO=DF_FILTRADO,
        DF_ALL=DF_ALL,
        IDEALES=IDEALES,
        get_predictor_cached=get_predictor_cached,
        pred_cache=st.session_state.get("pred_cache", {}),
    )

# ──────────────────────────────────────────────────────────────
# FOOTER
# ──────────────────────────────────────────────────────────────
md(f"""
<div style="text-align:center;font-size:.72rem;color:{MUTED};
border-top:1px solid {BORDER};padding-top:10px;margin-top:20px">
PRONACA · Dashboard v15 ++ · MODULARIZADO · {hoy:%d/%m/%Y %H:%M}
</div>
""")
